setwd("/Users/huyingchao/Desktop/TA/genomics/IntroToR")
getwd()

#===========基本命令============

##创建文件夹
dir.create("./plot")
##保存工作空间至IntroToR.RData
save.image("./IntroToR.RData")
##加载指定的工作空间
load("./IntroToR.RData")
##列出当前目录下的所有文件
list.files()

###数据框（data.frame)
d <- data.frame(name=c("Alice","Bob","Carol"),age=c(10,20,30))
class(d)
d


#============包==============
library("ggplot2")
library("patchwork")
library(openxlsx)


#============文件读写==============
##读入excel
dt1 <- read.xlsx("./students.xlsx")
dt1
##读入csv文件
dt2 <- read.csv("./students.csv",sep=",")
str(dt2) ##查看对象结构
##输出文本文件
write.table(d,file="students.txt",sep="\t",row.names = F, col.names = T, quote = F)
list.files(pattern = "txt")

#===============作图================
#######基本图形######
##散点图
age <- c(1, 3, 5, 2, 11, 9, 3, 9, 12, 3)
weight <- c(4.4, 5.3, 7.2, 5.2, 8.5, 7.3, 6, 10.4, 10.2, 6.1)
plot(age, weight)  
abline(lm(weight~age))  ##添加拟合线
title("Regression of age on weight") #添加标题

##直方图
#导入R内置数据集mtcars
#wt 车身重量
#mpg 每加仑汽油行驶的英里数
library(datasets)
data(mtcars)
hist(mtcars$wt, main = "Histogram of wt", xlab="wt")  ##直方图函数

##箱线图+保存图片
pdf("./plot/boxplot.pdf",width = 8,height = 6) 
boxplot(mtcars$wt, main = "Boxplot of wt") ##箱线图函数
dev.off() ##关闭图形设备
list.files(path ="./plot",pattern = "pdf")

##图形的简单组合
##par()函数中 参数mfrow=c(nrows,ncols) 创建按行填充的，行数为nrows，列数为ncols的图形矩阵
opar <- par(no.readonly = TRUE)
par(mfrow = c(2, 2))  ##两行两列排布
plot(mtcars$wt, mtcars$mpg, xlab="wt", ylab="mpg", main = "Scatterplot of wt vs. mpg")
plot(mtcars$wt, mtcars$disp, xlab="wt", ylab="disp",main = "Scatterplot of wt vs disp")
hist(mtcars$wt, xlab="wt", main = "Histogram of wt")
boxplot(mtcars$wt, main = "Boxplot of wt")


#######使用ggplot2进行高级绘图######
##baseR
##图形参数函数par()
##lwd 指定线条宽度
##cex 指定符号大小
##lty 指定线条类型
##pch 指定绘图时的符号
##col 绘图颜色
##xlim ylim 指定x，y轴坐标范围
##font.lab 坐标轴名称的字体样式
dose <- c(20, 30, 40, 45, 60)
drugA <- c(16, 20, 27, 40, 60)
drugB <- c(15, 18, 25, 31, 40)
opar <- par(no.readonly = TRUE) #生成一个可修改的当前图形参数列表
par(lwd = 2, cex = 1.5, font.lab = 2) #par 图形参数函数
plot(dose, drugA, type = "b", pch = 15, lty = 1, col = "red", 
     ylim = c(0, 60), main = "Drug A vs. Drug B", xlab = "Drug Dosage", 
     ylab = "Drug Response")
lines(dose, drugB, type = "b", pch = 17, lty = 2, 
      col = "blue")
legend("topleft", inset = 0.05, title = "Drug Type", 
       c("A", "B"), lty = c(1, 2), pch = c(15, 17), col = c("red","blue"))

##ggplot2
data_table <- data.frame(dose=c(dose,dose),response=append(drugA,drugB),label=c(rep('drugA',5),rep('drugB',5)))
ggplot() + 
  geom_point(data = data_table,aes(x=dose,y=response,colour=label,shape=label),size=4) + 
  scale_colour_manual(values = c(drugA='red',drugB='blue')) + 
  scale_shape_manual(values = c(drugA=15,drugB=17)) + 
  geom_line(data = data_table[data_table$label == 'drugA',],aes(x=dose,y=response),size=1,colour='red',linetype=1) + 
  geom_line(data = data_table[data_table$label == 'drugB',],aes(x=dose,y=response),size=1,colour='blue',linetype=2) + 
  theme_bw() + 
  ylim(c(0,60)) + 
  labs(title = 'Drug A vs. Drug B') + 
  xlab("Drug Dosage") + 
  ylab("Drug Response") +
  theme(aspect.ratio = 0.8, ##设置高宽比
        legend.position = c(0.1,0.7),
        plot.title = element_text(hjust = 0.5,size=20,),
        axis.text.x = element_text(size = 15,angle=0, hjust=0.5, vjust=1,color='black',),
        axis.text.y = element_text(size = 15,color='black',),
        axis.title.y = element_text(size = 15,color='black',),
        axis.title.x = element_text(size = 15,color='black',),
        legend.background = element_rect(fill = NA,colour = 'black',linewidth = 0.3),##设置图例背景、边框
  )


##ggplot2 组合几何函数形成新类型的图
data (singer, package="lattice")
ggplot (singer, aes (x=voice.part, y=height)) + 
  geom_violin(fill="lightblue")+
  geom_boxplot (fill="lightgreen", width= .2)+
  theme(aspect.ratio = 0.8, ##设置高宽比
        plot.title = element_text(hjust = 0.5,size=20,),
        axis.text.x = element_text(size = 10,angle=0, hjust=0.5, vjust=1,color='black',),
        axis.text.y = element_text(size = 10,color='black',),
        axis.title.y = element_text(size = 15,color='black',),
        axis.title.x = element_text(size = 15,color='black',))

##ggplot生成刻面图
ggplot (data=singer, aes (x=height)) +
  geom_histogram (bins=30) + 
  facet_wrap (~voice.part, nrow=4)

##ggplot2 图形的组合
##patchwork与ggplot
library(patchwork)
p1 <- ggplot() + 
  geom_point(data = data_table,aes(x=dose,y=response,colour=label,shape=label),size=4) + 
  scale_colour_manual(values = c(drugA='red',drugB='blue')) + 
  scale_shape_manual(values = c(drugA=15,drugB=17)) + 
  geom_line(data = data_table[data_table$label == 'drugA',],aes(x=dose,y=response),size=1,colour='red',linetype=1) + 
  geom_line(data = data_table[data_table$label == 'drugB',],aes(x=dose,y=response),size=1,colour='blue',linetype=2) + 
  theme_classic() + ylim(c(0,60)) + labs(title = 'Drug A vs. Drug B') + 
  xlab("Drug Dosage") + ylab("Drug Response") + 
  theme(aspect.ratio = 0.5,
        plot.title = element_text(hjust = 0.5),
        legend.position = 'none')

temp <- data.frame(data=mtcars$wt)
p2 <- ggplot(temp) + 
  geom_violin(aes(y=data,x=1),fill = 'lightgrey',colour = 'black') + 
  geom_boxplot(aes(y=data,x=1),fill = 'black',colour='black',width = 0.1,outlier.alpha = 0) + 
  theme_classic() + 
  theme(aspect.ratio = 1.5)

p3 <- ggplot(data=temp) + 
  geom_histogram(aes(x=data),bins = 5,colour='black',fill=NA) + 
  theme_classic() + theme(aspect.ratio = 0.5) + xlab('wt')

p1+p2+p3+plot_layout(ncol = 2)


